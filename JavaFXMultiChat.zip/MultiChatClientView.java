package chapter33;

import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MultiChatClientView {
	private Stage stage;
	private TextField tFName, tFMessage;
	private TextArea textView;

	public MultiChatClientView(Stage stage) {
		this.stage = stage;

		Scene scene = new Scene(createFormContent(), 315, 195);
		stage.setTitle("Chat Client");
		stage.setScene(scene);
		stage.show();
	}

	public Pane createFormContent() {
		Pane pane = new Pane();

		GridPane gridPane = new GridPane();
		VBox vBox = new VBox();
		Label lblName = new Label("Name");
		Label lblEntText = new Label("Enter Text");
		tFName = new TextField();
		tFMessage = new TextField();
		textView = new TextArea();
		textView.setEditable(false);
		ScrollPane scrollPane = new ScrollPane(textView);
		scrollPane.setMaxSize(315, 145);

		gridPane.add(lblName, 0, 0);
		gridPane.add(lblEntText, 0, 1);
		gridPane.add(tFName, 1, 0);
		gridPane.add(tFMessage, 1, 1);

		vBox.getChildren().addAll(gridPane, scrollPane);
		pane.getChildren().add(vBox);

		return pane;

	}

	public Stage getStage() {
		// TODO Auto-generated method stub
		return stage;
	}

	public TextField getTFName() {
		return tFName;
	}

	public TextField getTFMessage() {
		return tFMessage;
	}

	public TextArea getTextView() {
		return textView;
	}

}

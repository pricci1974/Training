package chapter33;

import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class MultiChatServerView {
	private Scene scene;
	private TextArea ta;
	private Stage stage;

	public MultiChatServerView(Stage stage) {
		this.stage = stage;
		ta = new TextArea();

		scene = new Scene(new ScrollPane(ta), 300, 150);
		stage.setTitle("Chat Server");
		stage.setScene(scene);
		stage.show();
	}

	public Stage getStage() {
		return stage;
	}

	public void updateView(String status) {
		ta.appendText(status);
	}

}

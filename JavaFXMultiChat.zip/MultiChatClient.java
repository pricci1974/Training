package chapter33;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.input.KeyCode;
import javafx.stage.Stage;

public class MultiChatClient extends Application {

	private Socket socket;
	private DataInputStream fromServer;
	private DataOutputStream toServer;
	private String name = "";
	private String messageToServer = "";
	private String messageFromServer = "";
	private MultiChatClientView mCCView;

	@Override
	public void start(Stage primaryStage) {
		// TODO Auto-generated method stub
		mCCView = new MultiChatClientView(primaryStage);

		mCCView.getStage().setOnCloseRequest(e -> shutdownClient());

		new Thread(() -> {
			try {

				socket = new Socket("localhost", 8000);// connects to local host on port 8000

				// data streams
				fromServer = new DataInputStream(socket.getInputStream());

				toServer = new DataOutputStream(socket.getOutputStream());

				new Thread(() -> {
					try {
						while (true) {
							messageFromServer = fromServer.readUTF();
							updateView();
						}
					} catch (IOException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
				}).start();

				mCCView.getTFMessage().setOnKeyPressed(ke -> {
					if (ke.getCode() == KeyCode.ENTER) {
						getMessageFromView();
						// while (!message.equals("log off")) {
						try {
							toServer.writeUTF(name + ": " + messageToServer);
							toServer.flush();

						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}

						// }

					}
				});

			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}).start();
	}

	private void getMessageFromView() {
		// TODO Auto-generated method stub
		name = mCCView.getTFName().getText().trim();
		messageToServer = mCCView.getTFMessage().getText().trim();
		mCCView.getTFMessage().clear();
	}

	private void updateView() {
		mCCView.getTextView().appendText(messageFromServer + "\n");
	}

	private void shutdownClient() {
		// TODO Auto-generated method stub
		Platform.exit();
		System.exit(0);
	}

	public static void main(String[] args) {
		Application.launch(args);
	}
}

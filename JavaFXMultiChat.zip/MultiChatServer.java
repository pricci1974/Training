package chapter33;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Stage;

public class MultiChatServer extends Application {

	private ServerSocket serverSocket;
	private MultiChatServerView mCSView;
	private boolean on = true;
	protected String messageClient = "";
	protected String messageServer = "";
	private static ArrayList<ChatHandler> chats;
	private DataOutputStream output;
	private ChatHandler oneChat;

	public MultiChatServer() {

	}

	public MultiChatServer(Socket socket) throws IOException {
		// TODO Auto-generated constructor stub
		output = new DataOutputStream(socket.getOutputStream());

	}

	public void broadCast(String message) {

		for (ChatHandler i : chats) {
			try {
				i.getToClient().writeUTF(message);
				i.getToClient().flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				i.setClientState(false);
			}

			System.out.println(i.toString());
		}

	}

	@Override
	public void start(Stage primaryStage) {
		// TODO Auto-generated method stub
		mCSView = new MultiChatServerView(primaryStage);
		mCSView.getStage().setOnCloseRequest(e -> shutDownServer());
		chats = new ArrayList<>();

		new Thread(() -> {
			try {
				serverSocket = new ServerSocket(8000);
				Platform.runLater(() -> mCSView.updateView("Server started on " + new Date().toString() + "\n"));

				while (on) {
					Socket socket = serverSocket.accept();
					Platform.runLater(() -> mCSView.updateView("Client Connected on " + new Date().toString() + "\n"));

					Thread thread;
					oneChat = new ChatHandler(socket);
					thread = new Thread(oneChat);
					chats.add(oneChat);
					thread.start();

				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}).start();

	}

	private void shutDownServer() {
		// TODO Auto-generated method stub
		on = false;

		Platform.exit();
		System.out.println("server closed");
		System.exit(0);
	}

	public static void main(String[] args) {
		Application.launch(args);
	}

	public MultiChatServerView getmCSView() {
		return mCSView;
	}

	public DataOutputStream getOutput() {
		return output;
	}

	class ChatHandler extends MultiChatServer implements Runnable {
		private Socket socket;
		private DataInputStream fromClient;
		private DataOutputStream toClient;
		private boolean clientOn = true;
		private MultiChatServer cServer;

		public ChatHandler(Socket socket) throws IOException {
			// TODO Auto-generated constructor stub
			this.socket = socket;

			cServer = new MultiChatServer(socket);

		}

		@Override
		public void run() {
			// TODO Auto-generated method stub

			try {
				fromClient = new DataInputStream(socket.getInputStream());
				toClient = new DataOutputStream(socket.getOutputStream());

				while (clientOn) {
					if (!socket.isClosed()) {
						messageServer = fromClient.readUTF();
						messageClient = messageServer;
						Platform.runLater(() -> mCSView.updateView(messageServer + "\n"));
						cServer.broadCast(messageClient);
					}
				}

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		public DataOutputStream getToClient() {
			return toClient;
		}

		public void setClientState(boolean clientOn) {
			this.clientOn = clientOn;
		}

		public Socket getSocket() {
			return this.socket;
		}

	}

}

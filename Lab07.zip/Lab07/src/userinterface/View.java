package userinterface;

import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

//project imports

//==============================================================
public abstract class View extends Group {
	private String myClassName;

	// Class constructor
	// ----------------------------------------------------------
	public View(String classname) {

		myClassName = classname;
	}

	// Title node used in both screens
	// ----------------------------------------------------------
	protected Node createTitle() {

		HBox hBox = new HBox();
		hBox.setAlignment(Pos.BASELINE_CENTER);
		Text titleText = new Text("Invoice Calculator");
		titleText.setFont(Font.font("Arial", FontWeight.BOLD, 20));
		titleText.setFill(Color.DARKGREEN);
		hBox.getChildren().add(titleText);

		return hBox;
	}

}

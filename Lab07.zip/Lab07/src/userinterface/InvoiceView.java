// specify the package
package userinterface;

import java.util.Properties;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import model.Invoice;

// project imports

/**
 * The class containing the Invoice View for the Invoice Calculator application
 */
//==============================================================
public class InvoiceView extends View {

// Model, which this View talks to
	private Invoice myModel;

	// GUI components
	private ComboBox<String> salesTax;
	private TextField shirts;
	private TextField pants;
	private TextField ties;
	private TextField shoes;
	private TextField total;
	private Button submitButton;
	private Button cancelButton;
	private Button resetButton;

	// For showing error message
	private MessageView statusLog;

	// constructor for this class -- takes a model object
	// ----------------------------------------------------------
	public InvoiceView(Invoice invoice) // SAME PATTERN AS LoginView
	{
		super("InvoiceView");
		myModel = invoice;

		// create a container for showing the contents
		VBox container = new VBox(10);
		container.setPadding(new Insets(15, 5, 5, 5));

		// create our GUI components, add them to this panel
		container.getChildren().add(createTitle());
		container.getChildren().add(createFormContent());

		// Error message area
		container.getChildren().add(createStatusLog("  "));

		getChildren().add(container);

		populateFields();
	}

	// Create the main form content
	// -------------------------------------------------------------
	private VBox createFormContent() {
		VBox vbox = new VBox(10); // Used to house the GridPane and HBox for buttons

		GridPane grid = new GridPane(); // GridPane contains the form content except the bottom buttons
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(25, 25, 25, 25));

		Text shirtLabel = new Text("Shirts: "); // Label for TextField
		grid.add(shirtLabel, 0, 0);

		shirts = new TextField(); // Used to enter price of item
		// Process invoice by pressing enter while this box is highlighted
		shirts.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				processAction(e);
			}
		});
		grid.add(shirts, 1, 0);

		Text pantsLabel = new Text("Pants:"); // Label for TextField
		grid.add(pantsLabel, 0, 1);

		pants = new TextField(); // Used to enter price of item
		// Process invoice by pressing enter while this box is highlighted
		pants.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				processAction(e);
			}
		});
		grid.add(pants, 1, 1);

		Text tiesLabel = new Text("Ties:"); // Label for TextField
		grid.add(tiesLabel, 0, 2);

		ties = new TextField(); // Used to enter price of item
		// Process invoice by pressing enter while this box is highlighted
		ties.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				processAction(e);
			}
		});
		grid.add(ties, 1, 2);

		Text shoesLabel = new Text("Shoes: "); // Label for TextField
		grid.add(shoesLabel, 0, 3);

		shoes = new TextField(); // Used to enter price of item
		// Process invoice by pressing enter while this box is highlighted
		shoes.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				processAction(e);
			}
		});
		grid.add(shoes, 1, 3);

		Text salesTaxLabel = new Text("Sales Tax: %"); // Label for TextField
		grid.add(salesTaxLabel, 0, 4);

		salesTax = new ComboBox<String>(); // Box to select sales tax rate
		salesTax.setMinSize(100, 20);
		// Process invoice by pressing enter while this box is highlighted
		salesTax.setOnKeyPressed(new EventHandler<KeyEvent>() {

			@Override
			public void handle(KeyEvent e) {
				if (e.getCode() == KeyCode.ENTER) {
					processAction(e);
				}
			}
		});
		grid.add(salesTax, 1, 4);

		Text grandTotalLabel = new Text("Grand Total: "); // Label for TextField
		grid.add(grandTotalLabel, 0, 5);

		total = new TextField(); // Box to display total price including tax
		total.setEditable(false); // Prevents box from being edited by user
		grid.add(total, 1, 5);

		// button to calculate total
		submitButton = new Button("Calculate");
		submitButton.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				clearErrorMessage();
				// do the calculation
				processAction(e);
			}
		});

		// Button to clear the invoice and enter new prices
		resetButton = new Button("Reset");
		resetButton.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {

				// --------------------------------------------
				myModel.createAndShowInvoiceView();
			}
		});

		// Button to return to the login screen
		cancelButton = new Button("Back");
		cancelButton.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {

				// --------------------------------------------
				clearErrorMessage();
				myModel.cancelTransaction();
			}
		});

		// Container for the buttons
		HBox btnContainer = new HBox(10);
		btnContainer.setAlignment(Pos.CENTER);
		btnContainer.getChildren().add(submitButton);
		btnContainer.getChildren().add(resetButton);
		btnContainer.getChildren().add(cancelButton);

		vbox.getChildren().add(grid);
		vbox.getChildren().add(btnContainer);

		return vbox;
	}

	// Create the status log field
	// -------------------------------------------------------------
	private MessageView createStatusLog(String initialMessage) {
		statusLog = new MessageView(initialMessage);

		return statusLog;
	}

	// Used to populate items on the sales tax Combo box
	// -------------------------------------------------------------
	public void populateFields() {

		salesTax.getItems().add("3.00");
		salesTax.getItems().add("3.25");
		salesTax.getItems().add("3.50");
		salesTax.getItems().add("3.75");
		salesTax.getItems().add("4.00");
		salesTax.getItems().add("4.25");
		salesTax.getItems().add("4.50");
		salesTax.getItems().add("4.75");
		salesTax.getItems().add("5.00");
		salesTax.getItems().add("5.25");
		salesTax.getItems().add("5.50");
		salesTax.getItems().add("5.75");
		salesTax.getItems().add("6.00");
		salesTax.getItems().add("6.25");
		salesTax.getItems().add("6.50");
		salesTax.getItems().add("6.75");
		salesTax.getItems().add("7.00");
		salesTax.getItems().add("7.25");
		salesTax.getItems().add("7.50");
		salesTax.getItems().add("7.75");
		salesTax.getItems().add("8.00");
		salesTax.getItems().add("8.25");
		salesTax.getItems().add("8.50");
		salesTax.getItems().add("8.75");
		salesTax.getItems().add("9.00");

		salesTax.setValue(salesTax.getItems().get(4));
		total.setText("");
	}

	// process events generated from our GUI components
	// -------------------------------------------------------------
	@SuppressWarnings("unused")
	public void processAction(Event evt) {

		boolean subZero = false; // flag for item with price <0
		clearErrorMessage();
		// do the transfer

		String amountOfShirts = shirts.getText();
		String amountOfPants = pants.getText();
		String amountOfTies = ties.getText();
		String amountOfShoes = shoes.getText();

		String selectedSalesTax = salesTax.getValue();

		// Here, we are doing USER DATA VALIDATION
		// Sets all blank fields to 0 for user convenience
		if ((amountOfShirts == null) || (amountOfShirts.length() == 0)) {
			amountOfShirts = "0";
			shirts.setText("0");
		}
		if ((amountOfPants == null) || (amountOfPants.length() == 0)) {
			amountOfPants = "0";
			pants.setText("0");
		}
		if ((amountOfTies == null) || (amountOfTies.length() == 0)) {
			amountOfTies = "0";
			ties.setText("0");
		}

		if ((amountOfShoes == null) || (amountOfShoes.length() == 0)) {
			amountOfShoes = "0";
			shoes.setText("0");
		}

		// This checks for user input less than 0.
		String[] testArray = { amountOfShirts, amountOfPants, amountOfTies, amountOfShoes };
		for (int i = 0; i < testArray.length; i++) {
			if (testArray[i].charAt(0) == '-') {
				subZero = true;
				displayErrorMessage("Error: You can't have item less than 0");

			}
		}

		if (!subZero) {
			try {
				// Any non numerical input except '.' will trigger the exception
				double dollarShirts = Double.parseDouble(amountOfShirts);
				double dollarPants = Double.parseDouble(amountOfPants);
				double dollarTies = Double.parseDouble(amountOfTies);
				double dollarShoes = Double.parseDouble(amountOfShoes);
				double dollarSalesTax = Double.parseDouble(selectedSalesTax);

				// process invoice
				processInvoice(amountOfShirts, amountOfPants, amountOfTies, amountOfShoes, selectedSalesTax);

			} catch (Exception ex) {
				displayErrorMessage("Error: Incorrect price format");
			}
		}
	}

	/**
	 * Process the data selected and entered by user. Action is to pass this info on
	 * to the Invoice (Model) object by calling the appropriate method on the
	 * Invoice object.
	 */
	// ----------------------------------------------------------
	private void processInvoice(String amountOfShirts, String amountOfPants, String amountOfTies, String amountOfShoes,
			String selectedSalesTax) {

		// Properties used for transferring data
		Properties props = new Properties();
		props.setProperty("ShirtPrice", amountOfShirts);
		props.setProperty("PantsPrice", amountOfPants);
		props.setProperty("TiesPrice", amountOfTies);
		props.setProperty("ShoesPrice", amountOfShoes);
		props.setProperty("SalesTax", selectedSalesTax);
		// will process invoice
		myModel.processInvoice(props);
	}

	/**
	 * Displays results of processed invoice in the total TextField
	 */
	// ---------------------------------------------------------
	public void updateState(String key, Object value) {
		if (key.equals("GrandTotal") == true) {
			String val = (String) value;
			total.setText(val);
		}
	}

	/**
	 * Display error message
	 */
	// ----------------------------------------------------------
	public void displayErrorMessage(String message) {
		statusLog.displayErrorMessage(message);
	}

	/**
	 * Clear error message
	 */
	// ----------------------------------------------------------
	public void clearErrorMessage() {
		statusLog.clearErrorMessage();
	}
}

// specify the package
package model;
public class AccountHolder 
{
	public String username;
	public String password;
	public String fullName;

	//-------------------------------------------------
	public AccountHolder(String un, String pw, String fn)
	{
		username = un;
		password = pw;
		fullName = fn;
	}
}

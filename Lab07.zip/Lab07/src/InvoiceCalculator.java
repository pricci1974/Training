
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.stage.Stage;

// project imports

import model.Invoice;
import userinterface.MainStageContainer;
import userinterface.WindowPosition;

/**
 * This program uses JavaFX to render and calculate the total prices and sales
 * tax for four different clothing types. The program also features a login
 * screen to control access. The program was created using adaptations of
 * pre-existing code and original code.
 * 
 * @author (Peter Ricci) and (Caleb Secor)
 * 
 * @version (March 17, 2020)
 * 
 *          Adapted from the program: Loan version 1.00 by Sandeep Mitra and T M
 *          Rao
 *
 */
//==============================================================
public class InvoiceCalculator extends Application {

	private Invoice myInvoice; // the main behavior for the application

	/** Main frame of the application */
	private Stage mainStage;

	// start method for this class, the main application object
	// ----------------------------------------------------------
	public void start(Stage primaryStage) {
		System.out.println("Invoice Version 1.00");
		System.out.println("Copyright 2020 Peter Ricci and Caleb Secor");

		// Create the top-level container (main stage) and add
		// contents to it.
		MainStageContainer.setStage(primaryStage, "Mom and Pop's Clothing Store Version 1.00");
		mainStage = MainStageContainer.getInstance();

		// Finish setting up the stage
		// (ENABLE THE GUI TO BE CLOSED USING THE TOP RIGHT 'X' IN THE
		// WINDOW), and show it.
		mainStage.setOnCloseRequest(new EventHandler<javafx.stage.WindowEvent>() {
			@Override
			public void handle(javafx.stage.WindowEvent event) {
				System.exit(0);
			}
		});

		try {
			myInvoice = new Invoice();
		} catch (Exception exc) {
			System.err.println("InvoiceCalculator.InvoiceCalculator - could not create " + "Invoice!");
			exc.printStackTrace();
		}

		WindowPosition.placeCenter(mainStage);

		mainStage.show();
	}

	/**
	 * The "main" entry point for the application. Carries out actions to set up the
	 * application
	 */
	// ----------------------------------------------------------
	public static void main(String[] args) {
		launch(args);
	}

}

package chapter33;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Stage;

public class LoanClient extends Application {
	private double annualInterestRate;
	private int numberOfYears;
	private double loanAmount;
	private DataOutputStream toServer;
	private DataInputStream fromServer;
	private Socket socket;
	private double monthlyPayment;
	private double totalPayment;
	private LoanClientView lCView;
	private boolean goodToGo = false;

	@Override
	public void start(Stage primaryStage) {
		// create view object
		lCView = new LoanClientView(primaryStage);

		// shut down client
		lCView.getStage().setOnCloseRequest(e -> shutdownClient());

		// this thread runs the client
		new Thread(() -> {

			try {
				socket = new Socket("localhost", 8000);// connects to local host on port 8000

				// data streams
				fromServer = new DataInputStream(socket.getInputStream());

				toServer = new DataOutputStream(socket.getOutputStream());

				// this function is activated when the button is pressed on the view screen
				lCView.getButton().setOnAction(e -> {
					obtainData(); // validate data from gui
					// if the data is validated we are goodToGo
					if (goodToGo) {

						try {
							// send and receive the data
							toServer.writeDouble(annualInterestRate);
							toServer.writeInt(numberOfYears);
							toServer.writeDouble(loanAmount);
							toServer.flush();
							monthlyPayment = fromServer.readDouble();
							totalPayment = fromServer.readDouble();
							// display results
							updateResults(monthlyPayment, totalPayment);

							// reset the gatekeeper flag
							goodToGo = false;
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				});

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}).start(); // start the thread

	}

	private void updateResults(double monthlyPayment, double totalPayment) {
		// update the display
		lCView.results.appendText("Monthly Payment: " + String.valueOf(monthlyPayment) + "\n");
		lCView.results.appendText("Total Amount Paid: " + String.valueOf(totalPayment) + "\n");
	}

	private void shutdownClient() {
		// TODO Auto-generated method stub
		try {
			fromServer.close();
			toServer.close();
			socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Platform.exit(); // exit javafx
		System.exit(0); // exit jvm
	}

	private void obtainData() {
		// obtains and validates data
		String aInt = lCView.taAnnual.getText();
		String numYear = lCView.taNumYears.getText();
		String loanAmt = lCView.taLoanAmount.getText();
		if ((aInt.length() > 0) && (numYear.length() > 0) && (loanAmt.length() > 0)) {
			try {
				annualInterestRate = Double.parseDouble(lCView.taAnnual.getText());
				numberOfYears = Integer.parseInt(lCView.taNumYears.getText());
				loanAmount = Double.parseDouble(lCView.taLoanAmount.getText());
				goodToGo = true;
			} catch (Exception ex) {
				ex.printStackTrace();
				System.out.println("Error with data");
				annualInterestRate = 0;
				numberOfYears = 0;
				loanAmount = 0;
			}
		}
	}

	public static void main(String[] args) {
		Application.launch(args);
	}

	public DataOutputStream getDataOutputStream() {
		return toServer;

	}

}

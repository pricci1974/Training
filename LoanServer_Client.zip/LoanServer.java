package chapter33;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;

import chapter10.Loan;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Stage;

public class LoanServer extends Application {
	private ServerSocket serverSocket; // needed for Server
	private Loan loan; // Loan object in subclass for computations
	// variables needed for computations
	private double annualInterestRate;
	private int numberOfYears;
	private double loanAmount;
	// ----------------------------------
	private LoanServerView lSView;// Creates a view object for iterations
	private boolean on = true; // needed to shut down thread
	private ArrayList<Thread> threadGroup; // experimenting with threadgroups and identifying individual threads

	@Override
	public void start(Stage primaryStage) throws java.net.SocketException {
		// TODO Auto-generated method stub
		lSView = new LoanServerView(primaryStage);// instantiates view object with primaryStage

		threadGroup = new ArrayList<>();// instantiates threadgroup
		lSView.getStage().setOnCloseRequest(e -> shutDownServer());// shuts down server when serverview is closed

		// server is started on its own thread, separate from the platform.
		new Thread(() -> {
			try {

				serverSocket = new ServerSocket(8000); // starts server
				// update view. this runs the update on the platform thread
				Platform.runLater(() -> lSView.updateView("Server started on " + new Date().toString() + "\n"));

				// continuous loop. each time a client connects, a new thread is started.
				while (on) {
					// waits for connection from client thread stops here until connected
					Socket socket = serverSocket.accept();
					Platform.runLater(() -> lSView.updateView("Connected to client " + new Date().toString() + "\n"));

					// new thread created, new Session. added to list of threads for fun
					Thread thread = new Thread(new Session(socket));
					threadGroup.add(thread);
					thread.start();
					for (Thread i : threadGroup) {
						Platform.runLater(() -> lSView.updateView("Client ID " + i.getName() + "\n"));

					}

				}

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}).start();// start the main server thread
	}

	private void shutDownServer() {
		// TODO Auto-generated method stub
		on = false;

		Platform.exit();
		System.out.println("server closed");
		System.exit(0);
	}

	// each client gets their own thread
	class Session implements Runnable {
		private Socket socket;
		private DataInputStream inputFromClient;
		private DataOutputStream outputToClient;
		private boolean clientOn = true;

		public Session(Socket socket) {
			// TODO Auto-generated constructor stub
			this.socket = socket;

		}

		@Override
		public void run() {
			// TODO Auto-generated method stub
			try {
				// create data streams
				inputFromClient = new DataInputStream(socket.getInputStream());
				outputToClient = new DataOutputStream(socket.getOutputStream());

				// read data from the client, create loan object to process data then send it
				// back out
				while (clientOn) {

					annualInterestRate = inputFromClient.readDouble();
					Platform.runLater(() -> lSView.updateView("Annual Interest Rate: " + annualInterestRate + "\n"));
					numberOfYears = inputFromClient.readInt();
					Platform.runLater(() -> lSView.updateView("Number of Years: " + numberOfYears + "\n"));
					loanAmount = inputFromClient.readDouble();
					Platform.runLater(() -> lSView.updateView("Loan Amount: " + loanAmount + "\n"));

					loan = new Loan(annualInterestRate, numberOfYears, loanAmount);

					outputToClient.writeDouble(loan.getMonthlyPayment());
					Platform.runLater(() -> lSView.updateView("Monthly Payment: " + loan.getMonthlyPayment() + "\n"));
					outputToClient.writeDouble(loan.getTotalPayment());
					Platform.runLater(() -> lSView.updateView("Total Payment: " + loan.getTotalPayment() + "\n"));

				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	public static void main(String[] args) {
		Application.launch(args);
	}

}

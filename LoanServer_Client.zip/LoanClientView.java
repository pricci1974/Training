package chapter33;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LoanClientView {
	private Stage stage;
	protected TextArea results;
	protected TextField taAnnual, taNumYears, taLoanAmount;
	private Scene scene;
	private VBox vBox;
	private GridPane gridPane;
	private Label lblAnnual, lblNumYears, lblLoanAmount;
	private ScrollPane scrollPane;
	private Button btnSubmit;

	public LoanClientView(Stage stage) {

		this.stage = stage;

		scene = new Scene(createDisplay(), 315, 225);
		stage.setTitle("Loan Client");
		stage.setScene(scene);
		stage.show();

	}

	private Pane createDisplay() {
		// TODO Auto-generated method stub
		Pane pane = new Pane();

		lblAnnual = new Label("Annual Interest Rate");
		lblNumYears = new Label("Number of Years");
		lblLoanAmount = new Label("Loan Amount");

		taAnnual = new TextField();
		taNumYears = new TextField();
		taLoanAmount = new TextField();

		btnSubmit = new Button("Submit");

		gridPane = new GridPane();
		gridPane.add(lblAnnual, 0, 0);
		gridPane.add(lblNumYears, 0, 1);
		gridPane.add(lblLoanAmount, 0, 2);
		gridPane.add(taAnnual, 1, 0);
		gridPane.add(taNumYears, 1, 1);
		gridPane.add(taLoanAmount, 1, 2);
		gridPane.add(btnSubmit, 2, 1);

		vBox = new VBox(5);
		results = new TextArea();
		scrollPane = new ScrollPane(results);
		scrollPane.setMaxSize(315, 145);

		vBox.getChildren().addAll(gridPane, scrollPane);

		pane.getChildren().add(vBox);
		return pane;

	}

	public Button getButton() {
		return btnSubmit;

	}

	public Stage getStage() {
		return stage;
	}

}

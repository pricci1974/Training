/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package staffDB;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author pdr04
 */
public class StaffDB extends HttpServlet {
    private PreparedStatement ppStmt;
    private DatabaseMetaData meta;
    private Connection conn;
    private String connectionStatus = "";
    private String valueID ="";
    private String valueLName = "";
    private String valueFName = "";
    private String valueMI ="";
    private String valueAdd = "";
    private String valueCity = "";
    private String valueState = "";
    private String valuePhone = "";
   
    @Override
    public void init() throws ServletException{
        initDatabase();
        
    }
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         
        
        response.setContentType("text/html;charset=UTF-8");
           
        PrintWriter out = response.getWriter();
        out.print("<!DOCTYPE html>\n" +
                "<html>\n" +
                "<head>\n" +
                "<style>\n" +
                ".fieldset-auto-width{\n" +
                "display: inline-block;\n" +
                "}\n" +
                "</style>\n" +
                "<body>\n" + 
                "<table><tr><td>\n" +  
                "<form method=\"post\" action=\"StaffDB\">\n" +
                "<fieldset class=\"fieldset-auto-width\">\n" +
                "<legend>Staff Information</legend>\n" +
                "<p> ID: <input type=\"text\" name=\"id\" value=\"" + valueID + "\" size=\"8\" /></p>\n" +
                "<p> Last Name: <input type=\"text\" name=\"lastName\" value=\"" + valueLName + "\" size=\"20\"/>\n" +
                "First Name: <input type=\"text\" name=\"firstName\" value=\"" + valueFName + "\" size=\"20\"/>\n" +
                "MI: <input type=\"text\" name=\"mi\" value=\"" + valueMI +"\" size=\"2\"/></p>\n" +
                "<p>Address: <input type=\"text\" name=\"address\" value=\"" + valueAdd + "\" size=\"25\"/></p>\n" +
                "<p>City: <input type=\"text\" name=\"city\" value=\"" + valueCity + "\" size=\"25\"/>\n" +
                "State: <input type=\"text\" name=\"state\" value=\"" + valueState + "\" size=\"2\"/></p>\n" +
                "<p>Telephone: <input type=\"text\" name=\"phone\" value=\"" + valuePhone + "\" size=\"13\"/></p>\n" +
                "</fieldset>\n" +
                "</td></tr>\n" +
                "<tr align=\"center\"><td>\n" +
                "<input type=\"submit\" name=\"buttons\" value=\"View\"/>\n" +
                "<input type=\"submit\" name=\"buttons\" value=\"Insert\"/>\n" +
                "<input type=\"submit\" name=\"buttons\" value=\"Update\"/>\n" +
                "<input type=\"submit\" name=\"buttons\" value=\"Reset\"/>\n" +
                "</td></tr>\n" +    
                "</form>\n" +
                "</table>\n" +  "<br>" +
                connectionStatus + "\n" +
                "</body>\n" +
                "</html>");
     }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
   
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        valueID = request.getParameter("id");
        valueLName = request.getParameter("lastName");
        valueFName = request.getParameter("firstName");
        valueMI = request.getParameter("mi");
        valueAdd = request.getParameter("address");
        valueCity = request.getParameter("city");
        valueState = request.getParameter("state");
        valuePhone = request.getParameter("phone");
        
        String button = request.getParameter("buttons");
        
         if ("View".equals(button))
                viewFunction();
         
        if ("Insert".equals(button))
            insertFunction();
        
        if ("Update".equals(button))
            updateFunction();
        
        if ("Reset".equals(button))
            clearForm();
        
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void initDatabase() {
        
        try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver loaded");

			conn = DriverManager.getConnection("jdbc:mysql://localhost/javabook", "scott", "tiger");
                       
			connectionStatus = "Connected to database; choose 5-digit ID to view record.";
	} catch (ClassNotFoundException | SQLException ex) {
                   connectionStatus = "error";
	}
        
    }
    
    private void viewFunction(){
        System.out.println("View button pressed");
        try {
            ppStmt = conn.prepareStatement("SELECT ID, lastName, firstName, mi, address, city, state, phone FROM address2 "
                    + "where ID =?");
            
            ppStmt.setString(1, valueID);
            ResultSet rset = ppStmt.executeQuery();
            
            if (rset.next()){
                valueID = rset.getString(1);
                valueLName = rset.getString(2);
                valueFName = rset.getString(3);
                valueMI = rset.getString(4);
                valueAdd = rset.getString(5);
                valueCity = rset.getString(6);
                valueState = rset.getString(7);
                valuePhone = rset.getString(8);
            }
             connectionStatus = "Viewing Record #" + valueID;
        } catch (SQLException ex) {
            connectionStatus = "Error retrieving record";
        }
        
       
    }

    private void insertFunction() {
        try {
            ppStmt = conn.prepareStatement("INSERT INTO address2 " +
                    "(ID, lastName, firstName, mi, address, city, state, phone) VALUES " +
                    "(?, ?, ?, ?, ?, ?, ?, ?)");
            
            ppStmt.setString(1, valueID);
            ppStmt.setString(2, valueLName);
            ppStmt.setString(3, valueFName);
            ppStmt.setString(4, valueMI);
            ppStmt.setString(5, valueAdd);
            ppStmt.setString(6, valueCity);
            ppStmt.setString(7, valueState);
            ppStmt.setString(8, valuePhone);
            ppStmt.executeUpdate();
            connectionStatus = "Record #" + valueID + " was saved." ;
        } catch (SQLException ex) {
            connectionStatus = "Error saving record";
        }
    }

    private void updateFunction() {
        String deleteCommand = "DELETE FROM address2 WHERE ID = ?";
        
        try {
            ppStmt = conn.prepareStatement(deleteCommand);
            ppStmt.setString(1, valueID);
            ppStmt.executeUpdate();

        } catch (SQLException ex) {
            connectionStatus = "Error updating record";
        }
        insertFunction();
    }

    private void clearForm() {
        try {
            valueID ="";
            valueLName = "";
            valueFName = "";
            valueMI ="";
            valueAdd = "";
            valueCity = "";
            valueState = "";
            valuePhone = "";
            meta = conn.getMetaData();
            connectionStatus = (conn.isValid(5))? "Connected to " + meta.getURL(): "closed";
            
        } catch (SQLException ex) {
            Logger.getLogger(StaffDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
}

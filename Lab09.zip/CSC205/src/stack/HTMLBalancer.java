package stack;

/*
 * This class is used to define the open and closed tags. Also contains code to match
 * the open tags with their respective closed tags.
 */
public class HTMLBalancer extends TokenBalanceChecker {

	// This returns true if the String is an open tag
	@Override
	public boolean isOpenTag(String token) {

		return token.equalsIgnoreCase("<HTML>") || token.equalsIgnoreCase("<HEAD>") || token.equalsIgnoreCase("<BODY>")
				|| token.equalsIgnoreCase("<TITLE>") || token.equalsIgnoreCase("<BOLD>")
				|| token.equalsIgnoreCase("<H1>") || token.equalsIgnoreCase("<H2>") || token.equalsIgnoreCase("<H3>")
				|| token.equalsIgnoreCase("<P>") || token.equalsIgnoreCase("<EM>")
				|| token.equalsIgnoreCase("<CENTER>");
	}

	// This returns true if the String is an open tag
	@Override
	public boolean isClosedTag(String token) {

		return token.equalsIgnoreCase("</HTML>") || token.equalsIgnoreCase("</HEAD>")
				|| token.equalsIgnoreCase("</BODY>") || token.equalsIgnoreCase("</TITLE>")
				|| token.equalsIgnoreCase("</BOLD>") || token.equalsIgnoreCase("</H1>")
				|| token.equalsIgnoreCase("</H2>") || token.equalsIgnoreCase("</H3>") || token.equalsIgnoreCase("</P>")
				|| token.equalsIgnoreCase("</EM>") || token.equalsIgnoreCase("</CENTER>");
	}

	// This return true only when an open tag matches is respective closed tag
	@Override
	public boolean matches(String open, String closed) {

		return (open.equalsIgnoreCase("<HTML>") && closed.equalsIgnoreCase("</HTML>"))
				|| (open.equalsIgnoreCase("<HEAD>") && closed.equalsIgnoreCase("</HEAD>"))
				|| (open.equalsIgnoreCase("<BODY>") && closed.equalsIgnoreCase("</BODY>"))
				|| (open.equalsIgnoreCase("<TITLE>") && closed.equalsIgnoreCase("</TITLE>"))
				|| (open.equalsIgnoreCase("<BOLD>") && closed.equalsIgnoreCase("</BOLD>"))
				|| (open.equalsIgnoreCase("<H1>") && closed.equalsIgnoreCase("</H1>"))
				|| (open.equalsIgnoreCase("<H2>") && closed.equalsIgnoreCase("</H2>"))
				|| (open.equalsIgnoreCase("<H3>") && closed.equalsIgnoreCase("</H3>"))
				|| (open.equalsIgnoreCase("<P>") && closed.equalsIgnoreCase("</P>"))
				|| (open.equalsIgnoreCase("<EM>") && closed.equalsIgnoreCase("</EM>"))
				|| (open.equalsIgnoreCase("<CENTER>") && closed.equalsIgnoreCase("</CENTER>"));

	}
}

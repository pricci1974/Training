package stack;

import java.util.ArrayList;

/*
 * This program reads a text file containing HTML tags and determines
 * if the code is balanced or unbalanced. Balanced code has open tags with 
 * corresponding matching closed tags. This uses the ArrayListStack class.
 * 
 * @authors (Peter Ricci) and (Caleb Secor)
 * 
 * @param (April 8, 2020)
 * 
 */

public abstract class TokenBalanceChecker implements BalanceChecker {

	// abstract methods
	public abstract boolean matches(String open, String closed);

	public abstract boolean isOpenTag(String token);

	public abstract boolean isClosedTag(String token);

	// This method checks if the ArrayList of Strings is balanced
	@Override
	public boolean isBalanced(ArrayList<String> tokenList) {

		// ArrayListStack object
		ArrayListStack<String> stackList = new ArrayListStack<>();

		/*
		 * This loop checks the list and assign a single string to word if the word is
		 * an open tag it is pushed to the stack; closed tag words are matched with the
		 * last open tag on the stack. If the stack is empty when attempting to match
		 * words, then the array is returns not balanced. If the word is present and
		 * does not match the open tag, then that too means the array is not balanced.
		 */
		for (int i = 0; i < tokenList.size(); i++) {
			String word = tokenList.get(i); //
			if (isOpenTag(word)) //
				stackList.push(word); // on the stack.
			else if (isClosedTag(word)) { //
				if (stackList.isEmpty()) //
					return false; // is not balanced
				String word1 = stackList.top();
				if (!matches(word1, word))
					return false;
				stackList.pop(); // If the two words match, then the last open tag word
									// is removed
			}

		}
		// if the stack has anything left, then the array was not balanced
		if (!stackList.isEmpty())
			return false;
		// if after every word is matched, the stack is emptied, and the arrays match
		return true;
	}

}

package stack;

/*
 * This class utilizes the IStack interface and related classes to convert
 * a decimal to a binary number.
 * 
 * @authors (Peter Ricci) and (Caleb Secor)
 * 
 * @version (April 8, 2020)
 */
public class DecToBinConverter {

	// Static method takes in an integer of base 10 to be converted to binary
	public static void printInBinary(int n) {
		// Create an ArrayStack<Integer> object
		IStack<Integer> s = new ArrayStack<Integer>(n);

		// 0 in 0 out.
		if (n == 0)
			System.out.println(0);

		// this statement takes the remainder of n mod 2 and pushes it
		// in stack s. n is then reassigned the value n / 2.
		while (n > 0) {
			int rem = n % 2;
			s.push(rem);
			n = n / 2;

		}

		// this statement will continue to print digits popped from
		// stack s until the stack is empty
		while (!s.isEmpty()) {
			int digit = s.pop();
			System.out.print(digit);
		}
	}
}

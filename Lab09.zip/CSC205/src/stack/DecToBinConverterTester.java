package stack;

// This program tests the DecToBinConverter program
public class DecToBinConverterTester {

	// main method
	public static void main(String[] args) {

		// List of test integers
		Integer[] numbers = { new Integer(23), new Integer(47), new Integer(257), new Integer(1023), new Integer(0),
				new Integer(82), new Integer(512), new Integer(100), new Integer(2049) };

		System.out.println("Decimal\tBinary"); // print headers
		// This takes all the ints from the list and uses the converter on them
		// to produce the binary outputs and prints the results.
		for (int i = 0; i < numbers.length; i++) {
			System.out.print(numbers[i] + "\t");
			DecToBinConverter.printInBinary(numbers[i]);
			System.out.println();
		}

	}

}

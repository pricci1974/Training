package stack;

/*
 * Interface used by TokenBalanceChecker
 */
import java.util.ArrayList;

public interface BalanceChecker {

	public boolean isBalanced(ArrayList<String> list);
}

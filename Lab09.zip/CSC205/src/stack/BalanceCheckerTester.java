package stack;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

/*
 * This class tests the BalanceChecker Program
 */
public class BalanceCheckerTester {

	// main method
	public static void main(String[] args) {
		// Location for the two test files. Array of files created for ease of testing
		File testFile1 = new File("C:\\Users\\pdr04\\eclipse-workspace\\CSC205\\src\\stack\\TestData1.txt");
		File testFile2 = new File("C:\\Users\\pdr04\\eclipse-workspace\\CSC205\\src\\stack\\TestData2.txt");
		File[] testFiles = { testFile1, testFile2 };

		// This loop tests both files including a try/catch statement
		for (int i = 0; i < testFiles.length; i++) {
			try {
				String data = " "; // will contain the data from the Scanner
				HTMLBalancer hb = new HTMLBalancer(); // HTMLBalancer object
				Scanner reader = new Scanner(testFiles[i]); // Scanner object to read the files
				ArrayList<String> htmlData1 = new ArrayList<>(); // ArrayList that will hold single strings

				// load the contents of the txt file to data string
				while (reader.hasNext())
					data += " " + reader.next();

				// use StringTokenizer object to split up the string
				StringTokenizer st1 = new StringTokenizer(data);

				// add each token to the array
				while (st1.hasMoreTokens())
					htmlData1.add(st1.nextToken());

				// create a string to streamline the results of both tests
				String results = "htmlData1 is" + (hb.isBalanced(htmlData1) ? "" : " NOT") + " balanced.";

				// print the results
				System.out.println(results);

				// close the Scanner object
				reader.close();
				// if the file is not found print a stack trace
			} catch (FileNotFoundException e) {

				e.printStackTrace();
			}
		}
	}

}

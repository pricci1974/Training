package userinterface;

import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

/*
 * This program streamlines the use of different types of text
 * throughout the GUI
 * 
 * @author (Peter Ricci)
 * 
 * @version (April 5, 2020)
 * 
 */

public class CustomText extends Text {

	// -----------------------------------------------------------------------
	// String variable used to contain the plain text
	private String text;
	// -----------------------------------------------------------------------

	/*
	 * The constructor
	 * 
	 * @param text: String object containing plain text
	 * 
	 */
	public CustomText(String text) {

		this.text = text;

	}
	// -----------------------------------------------------------------------

	/*
	 * This method creates the "standard" text labels used in the GUI
	 * 
	 * @param void
	 * 
	 * @return Text object that has been formatted
	 */
	public Text createRegularText() {

		// -----------------------------------------------------------------------
		// local variable used to hold the Text object
		Text regText = new Text(text);
		// -----------------------------------------------------------------------

		// this sets the type of text, font style and size
		regText.setFont(Font.font("Arial", FontWeight.BOLD, 20));
		// this sets the color of the text
		regText.setFill(Color.DARKGREEN);

		// this returns the formatted text
		return regText;
	}

	public Text createTitleText() {

		// -----------------------------------------------------------------------
		// local variable used to hold the Text object
		Text titleText = new Text(text);
		// -----------------------------------------------------------------------
		// this sets the type of text, font style and size
		titleText.setFont(Font.font("Arial", FontWeight.BOLD, 30));
		// this sets the color of the text
		titleText.setFill(Color.BLUE);

		// this returns the formatted text
		return titleText;
	}

	public Text createRedText() {

		// -----------------------------------------------------------------------
		// local variable used to hold the Text object
		Text redText = new Text(text);
		// -----------------------------------------------------------------------
		// this sets the type of text, font style and size
		redText.setFont(Font.font("Arial", FontWeight.BOLD, 20));
		// this sets the color of the text
		redText.setFill(Color.RED);

		// this returns the formatted text
		return redText;
	}

}

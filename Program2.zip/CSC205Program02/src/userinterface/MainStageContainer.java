package userinterface;

import javafx.stage.Stage;

/*
 * This program contains the main stage
 * 
 * @author (unknown)
 * 
 * @version (unknown)
 * 
 * 
 */
public class MainStageContainer {

	// -----------------------------------------------------------------------
	// static Stage object
	private static Stage myInstance;
	// -----------------------------------------------------------------------

	// class constructor
	// ----------------------------------------------------------
	private MainStageContainer() {
	}

	// ----------------------------------------------------------
	// Getter Method
	public static Stage getInstance() {
		return myInstance;
	}

	// -----------------------------------------------------------
	// Setter Method
	public static void setStage(Stage st, String title) {
		myInstance = st;
		myInstance.setTitle(title);
		myInstance.setResizable(false);
	}

}

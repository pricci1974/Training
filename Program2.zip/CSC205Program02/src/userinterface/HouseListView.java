package userinterface;

import java.util.ArrayList;
import java.util.Properties;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import model.FindMyHouse;
import model.House;

/*
 * This program is the GUI component
 * 
 * @author (Peter Ricci)
 * 
 * @version (April 5, 2020)
 * 
 */

public class HouseListView extends View {

	// -----------------------------------------------------------------------
	// this object holds the central set of attributes used throughout the program
	private FindMyHouse houseList;
	// -----------------------------------------------------------------------
	// this is the final, randomized list of houses to be shown to the user
	private ArrayList<House> finalList;
	// -----------------------------------------------------------------------
	// this object holds a user-input value for minimum price
	private TextField minPriceField;
	// -----------------------------------------------------------------------
	// this object holds a user-input value for maximum price
	private TextField maxPriceField;
	// -----------------------------------------------------------------------
	// this object holds a user-input value for minimum area
	private TextField minAreaField;
	// -----------------------------------------------------------------------
	// this object holds a user-input value for maximum area
	private TextField maxAreaField;
	// -----------------------------------------------------------------------
	// this object holds a user-input value for minimum number of bedrooms
	private TextField minBedsField;
	// -----------------------------------------------------------------------
	// this object holds a user-input value for maximum number of bedrooms
	private TextField maxBedsField;
	// -----------------------------------------------------------------------
	// this object is used to display one of the houses to the user
	private TextField chosenHomeDisplay;
	// -----------------------------------------------------------------------
	// this is the button to perform the search and return the results
	private Button findMyHouse;
	// -----------------------------------------------------------------------
	// this button allows the user to look at the next house
	private Button notMyHouse;
	// -----------------------------------------------------------------------
	// this button resets the program
	private Button reset;
	// -----------------------------------------------------------------------
	// this variable is used to index through the list of displayed houses
	private int viewIndex = 1;
	// -----------------------------------------------------------------------

	/*
	 * This is the constructor
	 * 
	 * @param findHouse: FindMyHouse object
	 */
	public HouseListView(FindMyHouse findHouse) {

		// invokes the super constructor
		super("HouseListView");

		// assigns findFouse to houseList
		this.houseList = findHouse;

		// -----------------------------------------------------------------------
		// create a container for showing the contents
		VBox container = new VBox(10);
		// -----------------------------------------------------------------------

		// creates insets for appearance
		container.setPadding(new Insets(15, 5, 5, 5));
		// adds objects from method call to container
		container.getChildren().add(createTitle());
		// adds objects from method call to container
		container.getChildren().add(createFormContent());
		// adds objects from method call to container
		container.getChildren().add(createDisplayArea());
		// adds objects from method call to container
		container.getChildren().add(createButtonBoxes());
		// adds container to the scene
		getChildren().add(container);

	}
	// -----------------------------------------------------------------------

	/*
	 * This method creates the title area
	 * 
	 * @param void
	 * 
	 * @return Node containing the title area
	 */
	private Node createTitle() {

		// -----------------------------------------------------------------------
		// HBox object containing the title area
		HBox hBox = new HBox();
		// -----------------------------------------------------------------------

		// sets the alignment for appearance
		hBox.setAlignment(Pos.BASELINE_CENTER);

		// creates CustomText and adds it to the HBox
		hBox.getChildren().add(new CustomText("Real Estate Listings").createTitleText());

		// returns the HBox object with its contents
		return hBox;
	}
	// -----------------------------------------------------------------------

	/*
	 * This method creates the main form of the GUI including the user accessed
	 * fields
	 * 
	 * @param void
	 * 
	 * @return GridPane containing all the nodes within
	 * 
	 */
	private GridPane createFormContent() {

		// -----------------------------------------------------------------------
		// GridPane contains TextFields for user input and labels
		GridPane grid = new GridPane();
		// -----------------------------------------------------------------------

		// this centers the alignment and sets padding for appearance
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(25);
		grid.setPadding(new Insets(25, 25, 25, 25));

		// this adds all the labels and places them in the proper grids
		grid.add(new CustomText("Minimum Price").createRegularText(), 0, 0);
		grid.add(new CustomText("Maximum Price").createRegularText(), 0, 1);
		grid.add(new CustomText("Minimum Area").createRegularText(), 0, 2);
		grid.add(new CustomText("Maximum Area").createRegularText(), 0, 3);
		grid.add(new CustomText("Minimum Beds").createRegularText(), 0, 4);
		grid.add(new CustomText("Maximum Beds").createRegularText(), 0, 5);

		// instantiates user area for minimum price
		minPriceField = new TextField();
		// this allows user to process action by pressing enter
		minPriceField.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				processAction(e);
			}
		});
		// adds TextField to GridPane
		grid.add(minPriceField, 1, 0);

		// instantiates user area fir maximum price
		maxPriceField = new TextField();
		// this allows user to process action by pressing enter
		maxPriceField.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				processAction(e);
			}
		});
		// adds TextField to GridPane
		grid.add(maxPriceField, 1, 1);

		// instantiates user area for minimum area
		minAreaField = new TextField();
		// this allows user to process action by pressing enter
		minAreaField.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				processAction(e);
			}
		});
		// adds TextField to GridPane
		grid.add(minAreaField, 1, 2);

		// instantiates user area for maximum area
		maxAreaField = new TextField();
		// this allows user to process action by pressing enter
		maxAreaField.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				processAction(e);
			}
		});
		// adds TextField to GridPane
		grid.add(maxAreaField, 1, 3);

		// instantiates user area for minimum number of bedrooms
		minBedsField = new TextField();
		// this allows user to process action by pressing enter
		minBedsField.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				processAction(e);
			}
		});
		// adds TextField to GridPane
		grid.add(minBedsField, 1, 4);

		// instantiates user area for maximum number of bedrooms
		maxBedsField = new TextField();
		// this allows user to process action by pressing enter
		maxBedsField.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {
				processAction(e);
			}
		});
		// adds TextField to GridPane
		grid.add(maxBedsField, 1, 5);

		// returns the grid
		return grid;
	}
	// -----------------------------------------------------------------------

	/*
	 * This creates the HBox containing the display area for the user
	 * 
	 * @param void
	 * 
	 * @return HBox containing display area
	 */
	private HBox createDisplayArea() {

		// -----------------------------------------------------------------------
		// creates HBox area that holds user display
		HBox hBox = new HBox(10);
		// -----------------------------------------------------------------------

		// this sets features for appearance
		hBox.setAlignment(Pos.CENTER);
		hBox.setPadding(new Insets(35, 25, 35, 25));

		// instantiates TextField that will display possible houses
		chosenHomeDisplay = new TextField();
		// sets the size of the display area
		chosenHomeDisplay.setMinSize(350, 40);
		// prevents user from entering data here
		chosenHomeDisplay.setEditable(false);

		// -----------------------------------------------------------------------
		// creates label for user display area
		Text cText = new CustomText("Chosen Home").createRedText();
		// -----------------------------------------------------------------------

		// adds TextField and text label to the HBox
		hBox.getChildren().add(cText);
		hBox.getChildren().add(chosenHomeDisplay);

		// returns the HBox object
		return hBox;

	}
	// -----------------------------------------------------------------------

	/*
	 * This method creates the area holding the three buttons
	 * 
	 * @param void
	 * 
	 * @return BorderPane containing the buttons
	 */
	private BorderPane createButtonBoxes() {

		// -----------------------------------------------------------------------
		// This is the BorderPane that will hold the buttons
		BorderPane buttonPane = new BorderPane();
		// -----------------------------------------------------------------------
		// creates a new Button with label and assigns it to findMyHouse
		findMyHouse = new Button("Find my dream house!");
		// -----------------------------------------------------------------------
		// when the button is pressed it calls processAction
		findMyHouse.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {

				// --------------------------------------------
				processAction(e);
			}
		});

		// -----------------------------------------------------------------------
		// creates a new Button with label and assigns it to notByHouse
		notMyHouse = new Button("Not my dream - find me another!");
		// -----------------------------------------------------------------------
		// when this button is pressed it calls the viewList method
		notMyHouse.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {

				// --------------------------------------------
				viewList();

			}
		});

		// -----------------------------------------------------------------------
		// creates a new Button with label and assigns it to reset
		reset = new Button("Reset");
		// -----------------------------------------------------------------------
		// when pressed, this button calls createAndShowHouseListView
		reset.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent e) {

				// --------------------------------------------
				houseList.createAndShowHouseListView();

			}
		});

		// This sets the sizes for the buttons
		reset.setMinSize(200, 30);
		findMyHouse.setMinSize(200, 30);
		notMyHouse.setMinSize(200, 30);
		// by default the notMyHouse button is disabled
		notMyHouse.setDisable(true);

		// -----------------------------------------------------------------------
		// creates and HBox to house two of the buttons
		HBox hBox = new HBox(20);
		// -----------------------------------------------------------------------
		// sets the alignment for appearance
		hBox.setAlignment(Pos.CENTER);
		// adds the buttons to the HBox
		hBox.getChildren().add(findMyHouse);
		hBox.getChildren().add(notMyHouse);

		// -----------------------------------------------------------------------
		// creates and HBox to house the reset button
		HBox rBox = new HBox();
		// -----------------------------------------------------------------------
		// sets the alignment for appearance
		rBox.setAlignment(Pos.CENTER);
		// adds the button to the HBox object
		rBox.getChildren().add(reset);

		// sets margin size of BorderPane for appearance
		BorderPane.setMargin(rBox, new Insets(10));

		// adds the panes containing the buttons to the BorderPane
		buttonPane.setCenter(hBox);
		buttonPane.setBottom(rBox);

		// returns the BorderPane
		return buttonPane;
	}
	// -----------------------------------------------------------------------

	/*
	 * This method is used to process the main event of the program
	 * 
	 * @param evt: Event object obtained from user input
	 * 
	 * @return void
	 */
	@SuppressWarnings("unused")
	private void processAction(Event evt) {

		// -----------------------------------------------------------------------
		// String object created to hold text from minPriceField
		String minPriceString = minPriceField.getText();
		// -----------------------------------------------------------------------
		// String object created to hold text from maxPriceField
		String maxPriceString = maxPriceField.getText();
		// -----------------------------------------------------------------------
		// String object created to hold text from minAreaField
		String minAreaString = minAreaField.getText();
		// -----------------------------------------------------------------------
		// String object created to hold text from maxAreaField
		String maxAreaString = maxAreaField.getText();
		// -----------------------------------------------------------------------
		// String object created to hold text from minBedsField
		String minBedsString = minBedsField.getText();
		// -----------------------------------------------------------------------
		// String object created to hold text from maxBedsField
		String maxBedsString = maxBedsField.getText();
		// -----------------------------------------------------------------------

		// After this button is clicked is the then disabled
		findMyHouse.setDisable(true);

		/*
		 * These if statements help to validate user input. If any minimum is left
		 * blank, it is converted to 0. If any maximum is left blank, the string is set
		 * to Integer.MAX_VALUE and the relative TextField is set to display NO LIMIT to
		 * the user.
		 */
		if ((minPriceString == null) || (minPriceString.length() == 0)) {
			minPriceString = "0";
			minPriceField.setText("0");
		}
		if ((maxPriceString == null) || (maxPriceString.length() == 0)) {
			maxPriceString = "" + Integer.MAX_VALUE;
			maxPriceField.setText("NO LIMIT");
		}
		if ((minAreaString == null) || (minAreaString.length() == 0)) {
			minAreaString = "0";
			minAreaField.setText("0");
		}
		if ((maxAreaString == null) || (maxAreaString.length() == 0)) {
			maxAreaString = "" + Integer.MAX_VALUE;
			maxAreaField.setText("NO LIMIT");
		}

		if ((minBedsString == null) || (minBedsString.length() == 0)) {
			minBedsString = "0";
			minBedsField.setText("0");
		}
		if ((maxBedsString == null) || (maxBedsString.length() == 0)) {
			maxBedsString = "" + Integer.MAX_VALUE;
			maxBedsField.setText("NO LIMIT");
		}

		// try catch to ensure there is a number in the user input TextField
		try {

			// -----------------------------------------------------------------------
			// variable to hold integer parsed from minPriceString
			int minPrice = Integer.parseInt(minPriceString);
			// -----------------------------------------------------------------------
			// variable to hold integer parsed from maxPriceString
			int maxPrice = Integer.parseInt(maxPriceString);
			// -----------------------------------------------------------------------
			// variable to hold integer parsed from minAreaString
			int minArea = Integer.parseInt(minAreaString);
			// -----------------------------------------------------------------------
			// variable to hold integer parsed from maxAreaString
			int maxArea = Integer.parseInt(maxAreaString);
			// -----------------------------------------------------------------------
			// variable to hold integer parsed from minBedsString
			int minBeds = Integer.parseInt(minBedsString);
			// -----------------------------------------------------------------------
			// variable to hold integer parsed from maxBedsString
			int maxBeds = Integer.parseInt(maxBedsString);
			// -----------------------------------------------------------------------

			/*
			 * These if statements are used to further validate user input: The TextField is
			 * set to "0" to display to the user and the relative String is also set to "0"
			 * so that field will be processed as a 0 instead of a negative number.
			 */
			if (minPrice < 0) {
				minPriceField.setText("0");
				minPriceString = "0";
			}

			if (minArea < 0) {
				minAreaField.setText("0");
				minAreaString = "0";
			}

			if (minBeds < 0) {
				minBedsField.setText("0");
				minBedsString = "0";
			}

			// process HouseList
			processHouseList(minPriceString, maxPriceString, minAreaString, maxAreaString, minBedsString,
					maxBedsString);

		} catch (Exception ex) {
			// If the user inputs any data that cannot be parsed, it will reset the program
			houseList.createAndShowHouseListView();
		}
	}
	// -----------------------------------------------------------------------

	/*
	 * This method takes the screened user input and processes it
	 * 
	 * @param minPrice: String containing minimum price
	 * 
	 * @param maxPrice: String containing maximum price
	 * 
	 * @param minArea: String containing minimum area
	 * 
	 * @param maxArea: String containing maximum area
	 * 
	 * @param minBeds: String containing minimum number of bedrooms
	 * 
	 * @param maxBeds: String containing maximum number of bedrooms
	 * 
	 * @return void
	 * 
	 */
	private void processHouseList(String minPrice, String maxPrice, String minArea, String maxArea, String minBeds,
			String maxBeds) {

		// Properties used for transferring data
		Properties props = new Properties();
		props.setProperty("minimumPrice", minPrice);
		props.setProperty("maximumPrice", maxPrice);
		props.setProperty("minimumArea", minArea);
		props.setProperty("maximumArea", maxArea);
		props.setProperty("minimumBeds", minBeds);
		props.setProperty("maximumBeds", maxBeds);

		// will process HouseList
		houseList.processHouseList(props);

		/*
		 * this takes the HouseList that meets the user specified criteria and calls the
		 * method to mix up the list and then assigns it to finalList
		 */
		finalList = houseList.getMeetCriteriaRandom();

		// this displays the first item in the list
		chosenHomeDisplay.setText(finalList.get(0).getAddress());

		// if a list is created, then notMyHouse is enabled.
		if (finalList.size() > 0)
			notMyHouse.setDisable(false);

	}
	// -----------------------------------------------------------------------

	/*
	 * This method displays the next item in the random list to the user for each
	 * call to this method. At the end of the list, the "no more houses" message is
	 * displayed and the notMyHouse button is disabled.
	 */
	private void viewList() {

		if (finalList.size() > 1 && viewIndex < finalList.size()) {
			chosenHomeDisplay.setText(finalList.get(viewIndex++).getAddress());
		} else {
			chosenHomeDisplay.setText("No more available houses");
			notMyHouse.setDisable(true);
		}
	}

}

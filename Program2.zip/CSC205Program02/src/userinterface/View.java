package userinterface;

import javafx.scene.Group;

//project imports

/*
 * Super Class used for other objects in the family
 * 
 * @author (unknown)
 * 
 * @version (unknown)
 */

//==============================================================
public abstract class View extends Group {

	@SuppressWarnings("unused")
	private String myClassName;

	// Class constructor
	// ----------------------------------------------------------
	public View(String classname) {

		this.myClassName = classname;
	}

	// Title node used in both screens
	// ----------------------------------------------------------

}

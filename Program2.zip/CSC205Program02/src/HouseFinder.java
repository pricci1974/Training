import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.stage.Stage;
import model.FindMyHouse;
import userinterface.MainStageContainer;

/*
 * This program Allows a user to search for their dream house by inputting
 * various search criteria; such as price, area and number of bedrooms. This
 * program utilizes a GUI via JavaFX.
 * 
 * @author (Peter Ricci)
 * 
 * @version (April 5, 2020)
 */
public class HouseFinder extends Application {

	// -----------------------------------------------------------------------
	// The FindMyHouse object is used throughout the program and holds attributes
	// needed
	// throughout the execution of the classes and the display of results.
	@SuppressWarnings("unused")
	private FindMyHouse findHouse;

	// -----------------------------------------------------------------------
	// The main stage container variable
	private Stage mainStage;
	// -----------------------------------------------------------------------

	/*
	 * This is the primary method needed for JavaFX programs
	 * 
	 * @param primaryStage: Stage object used as the main display container
	 * 
	 * @return void
	 */
	@Override
	public void start(Stage primaryStage) {

		// This call displays the title on the stage and implements attributes pre-set
		// in MainStageContainer
		MainStageContainer.setStage(primaryStage, "HouseFinder by Peter Ricci. Version April 5, 2020");

		// This gives a handle to the main stage for use in later functions.
		mainStage = MainStageContainer.getInstance();

		// This function allows the program to be terminated when the x is clicked on
		// the stage corner.
		mainStage.setOnCloseRequest(new EventHandler<javafx.stage.WindowEvent>() {
			@Override
			public void handle(javafx.stage.WindowEvent event) {
				System.exit(0);
			}
		});

		// Try/Catch function instantiates the FindMyHouse object or produces an error
		// message.
		try {
			findHouse = new FindMyHouse();

		} catch (Exception exc) {
			System.err.println("Could not Create View!");
			exc.printStackTrace();
		}

		// This function displays the GUI container.
		mainStage.show();

	}

	/*
	 * This is the main method used to launch the program
	 * 
	 * @param args : String array used in the launch call.
	 * 
	 * @return void
	 */
	public static void main(String[] args) {

		// This call starts the program.
		Application.launch(args);
	}

}

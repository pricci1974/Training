package model;

/*
 * Contains the search criteria entered by the user. Allows for an object
 * to be created to use for comparison
 * 
 * @author (Peter Ricci)
 * 
 * @version (February 29, 2020)
 */

public class Criteria {

	// -----------------------------------------------------------------------
	// Search criteria for entered by user
	private int minimumPrice;
	// -----------------------------------------------------------------------
	// Search criteria for entered by user
	private int maximumPrice;
	// -----------------------------------------------------------------------
	// Search criteria for entered by user
	private int minimumArea;
	// -----------------------------------------------------------------------
	// Search criteria for entered by user
	private int maximumArea;
	// -----------------------------------------------------------------------
	// Search criteria for entered by user
	private int minimumNumberOfBedrooms;
	// -----------------------------------------------------------------------
	// Search criteria for entered by user
	private int maximumNumberOfBedrooms;

	// -----------------------------------------------------------------------
	/*
	 * The constructor
	 * 
	 * @param minimumPrice: int containing search criteria entered by user
	 * 
	 * @param maximumPrice: int containing search criteria entered by user
	 * 
	 * @param minimumArea: int containing search criteria entered by user
	 * 
	 * @param maximumArea: int containing search criteria entered by user
	 * 
	 * @param minimumNumberOfBedrooms: int containing search criteria entered by
	 * user
	 * 
	 * @param maximumNumberOfBedrooms: int containing search criteria entered by
	 * user
	 */
	public Criteria(int minimumPrice, int maximumPrice, int minimumArea, int maximumArea, int minimumNumberOfBedrooms,
			int maximumNumberOfBedrooms) {

		this.minimumPrice = minimumPrice;
		this.maximumPrice = maximumPrice;
		this.minimumArea = minimumArea;
		this.maximumArea = maximumArea;
		this.minimumNumberOfBedrooms = minimumNumberOfBedrooms;
		this.maximumNumberOfBedrooms = maximumNumberOfBedrooms;

	}

	// -----------------------------------------------------------------------
	// Getter methods
	public int getMinimumPrice() {
		return minimumPrice;
	}

	// -----------------------------------------------------------------------
	public int getMaximumPrice() {
		return maximumPrice;
	}

	// -----------------------------------------------------------------------
	public int getMinimumArea() {
		return minimumArea;
	}

	// -----------------------------------------------------------------------
	public int getMaximumArea() {
		return maximumArea;
	}

	// -----------------------------------------------------------------------
	public int getMinimumBedrooms() {
		return minimumNumberOfBedrooms;
	}

	// -----------------------------------------------------------------------
	public int getMaximumBedrooms() {
		return maximumNumberOfBedrooms;
	}
}

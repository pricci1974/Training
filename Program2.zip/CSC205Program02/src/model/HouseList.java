package model;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * Creates an array of House objects. Essentially encapsulates
 * the array. Reads the data from a text file. Also works in conjunction
 * with Criteria object to create a list of houses that match the user search  
 * 
 * @author (Peter Ricci)
 * 
 * @version (April 5, 2020)
 */
public class HouseList {
	// -----------------------------------------------------------------------
	// Array containing House objects
	private ArrayList<House> houseList;
	// -----------------------------------------------------------------------
	// Scanner object used to access and read the text file
	private Scanner fileReader;
	// -----------------------------------------------------------------------
	// house address obtained from text file
	private String address;
	// -----------------------------------------------------------------------
	// house price obtained from text file
	private int price;
	// -----------------------------------------------------------------------
	// house area obtained from text file
	private int area;
	// -----------------------------------------------------------------------
	// house number of bedrooms obtained from text file
	private int numBedrooms;

	// -----------------------------------------------------------------------
	/*
	 * the constructor
	 * 
	 * @param fileName: String containing name/path of the file used to create list
	 * of House objects
	 */
	public HouseList(String fileName) {

		// try/catch needed for accessing file
		try {
			// Scanner object used to read the data from the file
			fileReader = new Scanner(new File(fileName));

			// initialize houseList
			houseList = new ArrayList<House>(0);

			// loop to read the file. Stops when no more data is found
			while (fileReader.hasNext()) {

				// reads the data and assigns it to each respective variable
				address = fileReader.next();
				price = fileReader.nextInt();
				area = fileReader.nextInt();
				numBedrooms = fileReader.nextInt();

				// creates new House object and adds it to the houseList array object
				houseList.add(new House(address, price, area, numBedrooms));

			}

			// ends the program with a message to user if the file is not found
		} catch (FileNotFoundException e1) {
			System.out.println("file: " + fileName + " was not found\nProgram Terminated.");
			System.exit(0);
		}
	}

	// -----------------------------------------------------------------------
	/*
	 * This method prints the search criteria entered by the user and prints the
	 * houses that are matches
	 * 
	 * @param c: Criteria object containing data from user
	 * 
	 * @return void
	 */
	public void printHouses(Criteria c) {

		// prints out the criteria using getHouses method
		System.out.println(this.getHouses(c));

		// for each method loops through entire list of houses
		// prints out only those that match using satisfies method
		for (House i : houseList)
			if (i.satisfies(c))
				System.out.println(i.toString());

	}

	// -----------------------------------------------------------------------
	/*
	 * This method produces/formats the search criteria entered by user as an output
	 * following the search
	 * 
	 * @param c: Criteria object containing data from user
	 * 
	 * @return String consisting of the formated information
	 */
	public String getHouses(Criteria c) {

		return "\nSearch Criteria:" + "\nMinumum Price: $" + c.getMinimumPrice() + "\nMaximum Price: $"
				+ c.getMaximumPrice() + "\nMinimum Area: " + c.getMinimumArea() + "\nMaximum Area: "
				+ c.getMaximumArea() + "\nMinumum Number of Bedrooms: " + c.getMinimumBedrooms()
				+ "\nMaximum Number of Bedrooms: " + c.getMaximumBedrooms()
				+ "\n\nThese are the houses we found based on the following criteria you entered:\n\n" + "\tAddress"
				+ "\t\tPrice\t\tArea\tNumber of Bedrooms";

	}

	// -----------------------------------------------------------------------
	/*
	 * This method returns an ArryList of House objects based on the user criteria
	 * 
	 * @param c: Criteria object containing data from user
	 * 
	 * @return ArrayList of House objects
	 */
	public ArrayList<House> getCustomerHouseList(Criteria c) {

		// -----------------------------------------------------------------------
		// local variable that will contain the list of houses to be returned
		ArrayList<House> customerList = new ArrayList<>();

		// this loop iterates though the list of House objects and adds
		// those that match the user criteria to the new ArrayList
		for (House i : houseList)
			if (i.satisfies(c))
				customerList.add(i);

		// returns the list of House objects
		return customerList;

	}
}

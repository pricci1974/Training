package model;

import java.util.ArrayList;
import java.util.Properties;

import javafx.scene.Scene;
import javafx.stage.Stage;
import userinterface.HouseListView;
import userinterface.MainStageContainer;
import userinterface.View;

/*
 * This class is used as a "bridge" between the GUI and the functioning part
 * of the program. It allows the previously written classes to remain largely 
 * unchanged.
 * 
 * @author (Peter Ricci)
 * 
 * @version (April 5, 2020)
 */

public class FindMyHouse {

	// -----------------------------------------------------------------------
	// Properties object used in communications between classes
	Properties props;
	// -----------------------------------------------------------------------
	// View object used in the GUI
	private View houseView;
	// -----------------------------------------------------------------------
	// HouseList object used to contain the master list of houses
	private static HouseList availableHouses;
	// -----------------------------------------------------------------------
	// This array will contain the list of houses that meet customer needs
	private ArrayList<House> meetCriteria;
	// -----------------------------------------------------------------------
	// This object will hold the attributes selected by the user
	private Criteria customerNeeds;
	// -----------------------------------------------------------------------
	// This is used to contain the display contents within the stage
	private Scene currentScene;
	// -----------------------------------------------------------------------
	// This object is the display container
	private Stage myStage;

	// -----------------------------------------------------------------------
	/*
	 * This is the constructor
	 * 
	 * @param void
	 */

	public FindMyHouse() {

		// This puts a handle on the stage
		myStage = MainStageContainer.getInstance();

		// This method calls the stage/scene creator
		createAndShowHouseListView();
	}

	// -----------------------------------------------------------------------
	/*
	 * This method creates and displays the stage
	 * 
	 * @param void
	 * 
	 * @param void
	 */
	public void createAndShowHouseListView() {

		// create our new view
		houseView = new HouseListView(this);

		// creates the scene within the stage
		currentScene = new Scene(houseView);

		// assigns the newly created scene to the main stage
		myStage.setScene(currentScene);

		// centers the stage on the center of the user view screen
		myStage.centerOnScreen();

	}

	// -----------------------------------------------------------------------
	/*
	 * This method received information from the user input via the GUI and handles
	 * the processing of the data
	 * 
	 * @param props: Property object containing user criteria
	 * 
	 * @return void
	 */

	public void processHouseList(Properties props) {

		// -----------------------------------------------------------------------
		// local String holds minimum price obtained from relative Property object
		String minPriceString = props.getProperty("minimumPrice");
		// -----------------------------------------------------------------------
		// local String holds maximum price obtained from relative Property object
		String maxPriceString = props.getProperty("maximumPrice");
		// -----------------------------------------------------------------------
		// local String holds minimum area obtained from relative Property object
		String minAreaString = props.getProperty("minimumArea");
		// -----------------------------------------------------------------------
		// local String holds maximum area obtained from relative Property object
		String maxAreaString = props.getProperty("maximumArea");
		// -----------------------------------------------------------------------
		// local String holds minimum number of bedrooms obtained from relative Property
		// object
		String minBedsString = props.getProperty("minimumBeds");
		// -----------------------------------------------------------------------
		// local String holds maximum number of bedrooms obtained from relative Property
		// object
		String maxBedsString = props.getProperty("maximumBeds");
		// -----------------------------------------------------------------------

		// This assigns the master list of properties to availableHouses object
		availableHouses = new HouseList("C:\\Users\\pdr04\\eclipse-workspace\\CSC205Program02\\src\\model\\houses.txt");

		// -----------------------------------------------------------------------
		// local int variable to hold minimum price data obtained from the relative
		// String
		int minPrice = Integer.parseInt(minPriceString);
		// -----------------------------------------------------------------------
		// local int variable to hold maximum price data obtained from the relative
		// String
		int maxPrice = Integer.parseInt(maxPriceString);
		// -----------------------------------------------------------------------
		// local int variable to hold minimum area data obtained from the relative
		// String
		int minArea = Integer.parseInt(minAreaString);
		// -----------------------------------------------------------------------
		// local int variable to hold maximum area data obtained from the relative
		// String
		int maxArea = Integer.parseInt(maxAreaString);
		// -----------------------------------------------------------------------
		// local int variable to hold minimum number of bedrooms data obtained from the
		// relative String
		int minBeds = Integer.parseInt(minBedsString);
		// -----------------------------------------------------------------------
		// local int variable to hold maximum number of bedrooms data obtained from the
		// relative String
		int maxBeds = Integer.parseInt(maxBedsString);
		// -----------------------------------------------------------------------

		// This creates Criteria object from local its and assigns it to customerNeeds.
		customerNeeds = new Criteria(minPrice, maxPrice, minArea, maxArea, minBeds, maxBeds);

		// This obtains the list of houses that meet criteria and assigns it to
		// meetCriteria.
		meetCriteria = availableHouses.getCustomerHouseList(customerNeeds);

	}
	// -----------------------------------------------------------------------

	/*
	 * This method takes an ArrayList of House objects and puts them in a random
	 * order to be displayed later.
	 * 
	 * @param void
	 * 
	 * @return ArrayList<House>: list of houses in random order
	 */

	public ArrayList<House> getMeetCriteriaRandom() {

		// -----------------------------------------------------------------------
		// local variable contains the length of the list of houses that met user needs
		int length = meetCriteria.size();
		// -----------------------------------------------------------------------
		// local variable used as an index for the while loop. Pre-assigned to 0
		int index = 0;
		// -----------------------------------------------------------------------
		// Local variable that will be assigned a random number to be used for mixing
		// the
		// list of houses.
		int randIndex = 0;
		// -----------------------------------------------------------------------
		// local array that will contain a list of random ints obtained from randIndex
		// this will be used to reassign the meetCriteria array
		ArrayList<Integer> randomArrayIndex = new ArrayList<>();
		// -----------------------------------------------------------------------
		// This array will be returned as the random list of selected houses
		ArrayList<House> randomList = new ArrayList<>();
		// -----------------------------------------------------------------------

		/*
		 * this while loop generates a random number from 0 to the length of the array -
		 * 1 and assigns it to randIndex. Next, it takes that random number and adds it
		 * to the randomArrayIndex only if that number is not already in the ArrayList,
		 * thus generating a list of random, non-repeating numbers from 0 to the length
		 * of the original list -1
		 * 
		 */
		while (index < length) {
			randIndex = (int) (Math.random() * length);
			if (!randomArrayIndex.contains(randIndex)) {
				randomArrayIndex.add(randIndex);
				index++;
			}
		}

		// This for loop takes the original list of houses and adds them to the
		// random list of houses based on the corresponding index of randomArrayIndex.
		// This finalizes the creation of the list of random houses.
		for (int i = 0; i < length; i++)
			randomList.add(meetCriteria.get(randomArrayIndex.get(i)));

		// returns the random list of houses that meet user criteria
		return randomList;
	}

}

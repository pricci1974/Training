package model;

/*
 * Creates a House object that contains important
 * attributes of a house including: address, price, area, and number
 * of bedrooms. It also includes a method used to check user criteria
 * for a search  
 * 
 * @author (Peter Ricci)
 * 
 * @version (February 29, 2020)
 */
public class House {

	// -----------------------------------------------------------------------
	// The address of the house obtained from text file
	private String address;
	// -----------------------------------------------------------------------
	// The price of the house obtained from text file
	private int price;
	// -----------------------------------------------------------------------
	// The area of the house obtained from text file
	private int area;
	// -----------------------------------------------------------------------
	// The number of bedrooms of the house obtained from text file
	private int numBedrooms;

	// -----------------------------------------------------------------------
	/*
	 * the constructor
	 * 
	 * @param address: String containing house address
	 * 
	 * @param price: int containing house price
	 * 
	 * @param area: int containing house area
	 * 
	 * @param numBedrooms: int containing house number of bedrooms
	 */
	public House(String address, int price, int area, int numBedrooms) {
		this.address = address;
		this.price = price;
		this.area = area;
		this.numBedrooms = numBedrooms;
	}

	// -----------------------------------------------------------------------
	// Getter methods
	public String getAddress() {
		return address;
	}

	// -----------------------------------------------------------------------
	public int getPrice() {
		return price;
	}

	// -----------------------------------------------------------------------
	public int getArea() {
		return area;
	}

	// -----------------------------------------------------------------------
	public int getNumBedrooms() {
		return numBedrooms;
	}

	// -----------------------------------------------------------------------
	/*
	 * This method compares the user input search criteria with the data contained
	 * in the text file
	 * 
	 * @param c: Criteria object containing data from user
	 * 
	 * @return boolean: true if the criteria matches house data, false otherwise
	 */
	public boolean satisfies(Criteria c) {
		return (this.price >= c.getMinimumPrice()) && (this.price <= c.getMaximumPrice())
				&& (this.area >= c.getMinimumArea()) && (this.area <= c.getMaximumArea())
				&& (this.numBedrooms >= c.getMinimumBedrooms() && (this.numBedrooms <= c.getMaximumBedrooms()));

	}

	// -----------------------------------------------------------------------
	/*
	 * toString method prints the house data in a nice format for the user
	 * 
	 * @param void
	 * 
	 * @return toString: String containing formatted information
	 */
	@Override
	public String toString() {
		return this.address + " \t" + "$" + this.price + "\t\t" + this.area + "\t\t" + this.numBedrooms;

	}
}
